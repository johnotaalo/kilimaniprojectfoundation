<p>Below are some useful contacts for your reference:</p>

<p><b>Kilimani Project Foundation:</b> 0780 197 197</p>
<p><b>St John's Ambulance:</b> 0721 225 285</p>
<p><b>Police Emergency:</b> 911</p>
<p><b>Kilimani Police Station:</b> 0712 179 562</p>
<p><b>Kilimani Traffic Department:</b> 020 272 1683</p>
<p><b>Kilimani Crime Officer Commanding Police Dept (OCPD) – Joseph Muthee:</b>  0722 341 194</p>
<p><b>Kilimani Crime Investigation Officer (CIO) – Phylis Kanina:</b> 0721 599 474 </p>
<p><b>Kilimani Crime Officer Commanding Station (OCS) – Gilbert Mgui:</b> 0713911974</p>
<p><b>Kilimani Ward Administrator – Meshack Omitti:</b> 0715 426 145</p>
<p><b>Kilimani Member of County Assembly (MCA) – Moses Ogeto:</b> 0752188888</p>
<p><b>Kilimani Chief – Patrick Adira:</b> 0722611082</p>
<p><b>Dhobi Cleaning Women – Grace:</b> 0728751705</p>
<p><b>Chandarana Foodplus Online Shopping:</b> www.foodplus.co.ke</p>
