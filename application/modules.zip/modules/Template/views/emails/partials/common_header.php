<!DOCTYPE html>
<html>
<head>
	<title>Kilimani Membership Email</title>
</head>
<body>

<p><?= @date('d-m-Y'); ?></p>

Dear <?= @$firstname; ?>, <?= @$lastname; ?>,