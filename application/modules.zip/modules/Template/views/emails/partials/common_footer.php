<p>We look forward to getting to know more about your business and engaging in community building together.</p>
 
<p>Sincerely,</p>
<img style="width: 100px;" src="<?= @base_url('assets/img/chairmans_signature.png'); ?>" />
 
<p>Martha Wamuyu | Programme Assistant, Kilimani Project Foundation</p>
<p>Mobile: +254780197197, +254721323002 | Twitter: @kilimanispeaks | www.kilimani.co.ke</p>

<?php if(isset($contacts)) {?>
	<?php $this->load->view('Template/emails/partials/contacts'); ?>
<?php } ?>

</body>
</html>