<div class="row">
    <div class="col-md-12">
        <h1>Successfully sent your request!</h1>
        <h4>Please fill in the instructions to complete your request</h4>
    </div>
</div>

<div class="jumbotron">
    <h4>If you had a problem and would like to repeat the process of payment, please click on the button below</h4>
    <center><a href = '<?= @base_url('Registration/payment/' . $type); ?>' class = 'btn btn-danger'>Return to Payment Page</a></center>
</div>